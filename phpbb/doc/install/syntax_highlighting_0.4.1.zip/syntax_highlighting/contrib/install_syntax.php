<?php
/***************************************************************************
 *                             install_syntax.php
 *                            --------------------
 *   begin                : Sunday, Aug 14, 2005
 *   copyright            : (C) 2005 Nigel McNie
 *   email                : nigel@geshi.org
 *
 *   $Id: install_syntax.php,v 1.1 2005/08/14 12:44:12 oracleshinoda Exp $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', 1);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);

//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);
//
// End session management
//

if (!$userdata['session_logged_in'])
{
    redirect(append_sid("login.$phpEx?redirect=install_syntax.$phpEx", true));
}
else if ($userdata['user_level'] != ADMIN)
{
    message_die(GENERAL_MESSAGE, $lang['Not_admin']);
}

//
// If here we're authenticated as an administrator
//
// TODO: multi-language
include($phpbb_root_path . 'language/lang_english/lang_admin.'.$phpEx);

//
// Function that handles installation and upgrading of MOD
//
function install_syntax_mod ()
{
	global $lang, $db;
	
	if (!defined('SYNTAX_HIGHLIGHTER_VERSION'))
	{
		message_die(GENERAL_MESSAGE, $lang['Syntax_installer_install_files_first']);
	}
	
	// Now it should be true that the files from the MOD are installed
	
	$sql = array(
		"INSERT INTO phpbb_config (config_name, config_value) VALUES ('syntax_status', '2')",
		"INSERT INTO phpbb_config (config_name, config_value) VALUES ('syntax_enable_cache', '1')",
		"INSERT INTO phpbb_config (config_name, config_value) VALUES ('syntax_cache_check_time', '5000')",
		"INSERT INTO phpbb_config (config_name, config_value) VALUES ('syntax_cache_dir_size', '20971520')",
		"INSERT INTO phpbb_config (config_name, config_value) VALUES ('syntax_cache_files_expire', '2592000')",
		"INSERT INTO phpbb_config (config_name, config_value) VALUES ('syntax_enable_line_numbers', '0')",
		"INSERT INTO phpbb_config (config_name, config_value) VALUES ('syntax_enable_urls', '1')",
		"INSERT INTO phpbb_config (config_name, config_value) VALUES ('syntax_version', '0.4.0')",
		
		"CREATE TABLE phpbb_syntax_language_config (language_file_name VARCHAR(30), lang_identifier VARCHAR(15), lang_display_name VARCHAR(25))",
		
		"INSERT INTO phpbb_syntax_language_config VALUES ('actionscript.php', 'actionscript', 'actionscript')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('ada.php', 'ada', 'ada')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('apache.php', 'apache', 'apache')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('asm.php', 'asm', 'asm')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('asp.php', 'asp', 'asp')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('bash.php', 'bash', 'bash')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('caddcl.php', 'caddcl', 'CAD DCL')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('cadlisp.php', 'cadlisp', 'CAD Lisp')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('c_mac.php', 'c_mac', 'C (Mac)')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('c.php', 'c', 'c')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('cpp.php', 'c++', 'c++')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('csharp.php', 'c#', 'C#')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('css.php', 'css', 'css')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('delphi.php', 'delphi', 'delphi')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('diff.php', 'diff', 'Diff Output')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('div.php', 'div', 'DIV')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('d.php', 'd', 'd')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('eiffel.php', 'eiffel', 'Eiffel')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('gml.php', 'gml', 'GML')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('html4strict.php', 'html', 'HTML')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('java.php', 'java', 'Java')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('javascript.php', 'javascript', 'Javascript')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('lisp.php', 'lisp', 'Lisp')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('lua.php', 'lua', 'Lua')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('matlab.php', 'matlab', 'Matlab')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('mpasm.php', 'mpasm', 'Microprocessor ASM')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('nsis.php', 'nsis', 'NullSoft Installer Script')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('objc.php', 'objc', 'Objective C')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('oobas.php', 'oobas', 'Openoffice.org BASIC')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('oracle8.php', 'oracle8', 'Oracle 8')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('pascal.php', 'pascal', 'Pascal')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('perl.php', 'perl', 'Perl')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('php-brief.php', 'php-brief', 'php (brief)')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('php.php', 'php', 'php')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('python.php', 'python', 'Python')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('qbasic.php', 'qbasic', 'QBasic')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('smarty.php', 'smarty', 'Smarty')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('sql.php', 'sql', 'SQL')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('vbnet.php', 'vbnet', 'VB.NET')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('vb.php', 'vb', 'VisualBASIC')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('vhdl.php', 'vhdl', 'VHDL')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('visualfoxpro.php', 'vfp', 'Visual FoxPro')",
		"INSERT INTO phpbb_syntax_language_config VALUES ('xml.php', 'xml', 'XML')"
	);
	
	foreach ($sql as $query)
	{
		if (!($result = $db->sql_query($query)))
		{
			message_die(GENERAL_ERROR, $lang['Syntax_installer_sql_failed'], '', __LINE__, __FILE__, $query);
		}
	}
	
	return $lang['Syntax_installer_mod_installed']; 
}

//
// Attempt to auto-detect whether this MOD has been installed before
//
if ($board_config['syntax_version'] && false)
{
	// Previous install!
	if ($_POST['submit'])
	{
		// Previous install, run update SQL
		$message = $lang['Syntax_installer_previous_install'];
	}
	else
	{
		// Previous install, show introduction
		$message = $lang['Syntax_installer_previous_install'];
	}
}
else
{
	// New install
	if ($_POST['submit'])
	{
		// New install, run install SQL etc.
		$message = install_syntax_mod();
	}
	else
	{
		// New install, show introduction
		$message = $lang['Syntax_installer_new_install'];
		$message .= '<br /><br /><center><form method="post"><input type="submit" name="submit" value="'
			. $lang['Syntax_installer_install_mod'] . '" class="mainoption" /></form></center>';
	}
}


include($phpbb_root_path . 'includes/page_header.'.$phpEx);

echo<<<EOF
<h1 class="gen">Syntax Highlighting MOD for phpBB</h1>
<span class="gensmall">$message</span>
EOF;

include($phpbb_root_path . 'includes/page_tail.'.$phpEx);

?>
